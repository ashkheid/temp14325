## Categories

- Variables, Data Types, and Operators - Beginner
- Conditional Statements and Loops - Beginner
- Functions and Scope - Lower-Intermediate
- Arrays and Objects - Lower-Intermediate
- DOM Manipulation and Event Handling - Intermediate
- Asynchronous JavaScript - Intermediate
- Error Handling and Debugging - Upper-Intermediate
- Higher-Order Functions and Closures - Advanced
- ES6+ Features (such as Arrow Functions, Classes, Promises, - etc.) - Advanced
- Functional Programming - Mastery


## Beginner

### Question 1

1. What is JavaScript and what are its main features?
1. How do you declare a variable in JavaScript?
1. What is the difference between let, const, and var?
1. What are data types in JavaScript?
1. How do you convert a string to a number in JavaScript?
1. What are operators in JavaScript?
1. How do you concatenate strings in JavaScript?

### Question 2

1. What are conditional statements and how are they used in JavaScript?
1. How do you write an if...else statement in JavaScript?
1. How do you write a switch statement in JavaScript?
1. What is truthy and falsy in JavaScript?
1. How do you use logical operators in JavaScript?
1. How do you write a ternary operator in JavaScript?
1. How do you use comparison operators in JavaScript?

### Question 3

1. What are loops and how are they used in JavaScript?
1. How do you write a for loop in JavaScript?
1. How do you write a while loop in JavaScript?
1. How do you use break and continue statements in loops in JavaScript?
1. What is a nested loop and how is it used in JavaScript?
1. How do you loop through an object in JavaScript?
1. What is the difference between for...in and for...of loops in JavaScript?

## Lower-Intermediate

### Question 1

1. What is function scope and how does it work in JavaScript?
1. How do you write a function declaration in JavaScript?
1. How do you write a function expression in JavaScript?
1. What is a callback function and how is it used in JavaScript?
1. How do you pass arguments to a function in JavaScript?
1. What is the difference between parameters and arguments in JavaScript?
1. What is a return statement and how is it used in JavaScript functions?

### Question 2

1. What are arrays and objects in JavaScript?
1. How do you create an array in JavaScript?
1. How do you add or remove elements from an array in JavaScript?
1. What is the difference between splice() and slice() methods in JavaScript arrays?
1. How do you loop through an array in JavaScript?
1. How do you sort an array in JavaScript?
1. What are multidimensional arrays and how are they used in JavaScript?

### Question 3

1. What is the Document Object Model (DOM) and how does it relate to JavaScript?
1. How do you select an HTML element using JavaScript?
1. How do you add or remove HTML elements using JavaScript?
1. How do you modify the content of an HTML element using JavaScript?
1. How do you add or remove CSS classes using JavaScript?
1. What are events and how do you handle them in JavaScript?
1. What is event bubbling and how does it work in JavaScript?

## Intermediate

### Question 1

1. What is scope in JavaScript and how does it work?
1. What is the difference between global and local scope in JavaScript?
1. What is hoisting in JavaScript and how does it affect variable and function declarations?
1. What are closures in JavaScript and how are they used?
1. What is the difference between a function declaration and a function expression in JavaScript?
1. How do you use the this keyword in JavaScript?
1. What is the difference between call(), apply(), and bind() methods in JavaScript?

### Question 2

1. What are higher-order functions in JavaScript and how are they used?
1. What is the difference between map(), filter(), and reduce() methods in JavaScript?
1. What are arrow functions in JavaScript and how are they used?
1. What is the difference between synchronous and asynchronous programming in JavaScript?
1. What is a callback function and how is it used in asynchronous programming in JavaScript?
1. What are promises in JavaScript and how are they used?
1. What are async/await functions in JavaScript and how are they used?

### Question 3

1. What is object-oriented programming (OOP) in JavaScript and how is it used?
1. What is a class in JavaScript and how do you create one?
1. What is inheritance in JavaScript and how is it used?
1. What are superclasses and subclasses in JavaScript?
1. What is encapsulation in JavaScript and how is it used?
1. What is polymorphism in JavaScript and how is it used?
1. What is composition in JavaScript and how is it used?

## Upper-Intermediate

## Question 1

1. What is the event loop in JavaScript and how does it work?
1. What is the difference between synchronous and asynchronous code in JavaScript?
1. What are callbacks and how are they used in asynchronous JavaScript?
1. What are promises and how are they used in asynchronous JavaScript?
1. What are async/await and how are they used in asynchronous JavaScript?
1. What is the difference between concurrency and parallelism in JavaScript?
1. How do you write concurrent JavaScript code?

## Question 2

1. What are closures in JavaScript and how are they used?
1. What is a lexical environment in JavaScript?
1. What is the difference between a block scope and a function scope in JavaScript?
1. How does JavaScript handle memory management?
1. What are garbage collection and how do they work in JavaScript?
1. What is the difference between shallow and deep copying in JavaScript?
1. How do you use the spread operator and destructuring in JavaScript?

## Question 3

1. What is the difference between JavaScript and TypeScript?
1. What are the advantages and disadvantages of using TypeScript over JavaScript?
1. What is a type system and how is it used in TypeScript?
1. What are interfaces in TypeScript and how are they used?
1. What are generics in TypeScript and how are they used?
1. What are decorators in TypeScript and how are they used?
1. How do you configure a TypeScript project and compile TypeScript code into JavaScript?

## Advanced

### Question 1

1. What is functional programming and how is it used in JavaScript?
1. What is the difference between imperative and declarative programming?
1. What is the difference between pure and impure functions in JavaScript?
1. How do you use currying and composition in JavaScript?
1. What are monads in functional programming and how are they used in JavaScript?
1. What are functors and how are they used in JavaScript?
1. What are higher-kinded types and how are they used in JavaScript?

### Question 2

1. What is the difference between prototypal and classical inheritance in JavaScript?
1. What is a prototype chain in JavaScript?
1. How does JavaScript implement inheritance and object composition?
1. What are mixins in JavaScript and how are they used?
1. What are traits in JavaScript and how are they used?
1. What is the difference between aggregation and composition in object-oriented programming?
1. How do you implement design patterns in JavaScript?

### Question 3

1. What is the difference between the DOM and the virtual DOM?
1. What is server-side rendering and how is it used in JavaScript?
1. How do you optimize the performance of a web application written in JavaScript?
1. What are lazy loading and code splitting in JavaScript and how are they used?
1. What are worker threads in JavaScript and how are they used?
1. How do you use web sockets in JavaScript to implement real-time communication?
1. What are serverless functions and how are they used in JavaScript?


## Mastery

### Question 1

1. What are the best practices for writing high-performance JavaScript code?
1. How do you optimize memory usage in JavaScript?
1. What are the performance implications of using different data structures in JavaScript?
1. How do you write JavaScript code that is both performant and maintainable?
1. How do you optimize the performance of a web application that uses a large amount of data?
1. What are the performance implications of using different JavaScript frameworks and libraries?
1. How do you perform profiling and debugging of JavaScript code?

### Question 2

1. What are the best practices for testing JavaScript code?
1. How do you write unit tests for JavaScript code?
1. What are the advantages and disadvantages of different JavaScript testing frameworks?
1. How do you write integration tests for a web application written in JavaScript?
1. How do you write end-to-end tests for a web application written in JavaScript?
1. How do you use mocking and stubbing to test JavaScript code?
1. How do you test asynchronous code in JavaScript?

### Question 3

1. What are the best practices for building scalable web applications with JavaScript?
1. How do you architect a web application for scalability and maintainability?
1. What are the performance implications of different web application architectures?
1. How do you optimize the performance of a web application that serves a large number of users?
1. How do you design a database schema for a web application written in JavaScript?
1. How do you implement caching in a web application written in JavaScript?
1. How do you implement load balancing and failover in a web application written in JavaScript?

---

## Coding Challenges

### Beginner 1

**Coding Challenge:**

Create a function that takes a string as input and returns an object containing the count of each character in the string. The function should ignore white spaces and be case-insensitive.

**Example:**

Input: `"Hello World"`

Output: `{h: 1, e: 1, l: 3, o: 2, w: 1, r: 1, d: 1}`

#### Solution 1:

```js
function countCharacters(str) {
  const result = {};
  str = str.toLowerCase().replace(/\s/g, '');
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    if (result[char]) {
      result[char]++;
    } else {
      result[char] = 1;
    }
  }
  return result;
}
```

#### Solution 2:

```JS
function countCharacters(str) {
  const result = {};
  str.toLowerCase().replace(/\S/g, function(char) {
    result[char] = result[char] + 1 || 1;
  });
  return result;
}
```

In Solution 1, we first convert the input string to lowercase and remove all the white spaces using regular expression. We then loop through each character in the modified string and count its occurrence using an object.

In Solution 2, we use a regular expression to match all non-space characters in the input string and call the replace() method with a callback function that updates the count of each character in the result object.



### Beginner 2

**Coding Challenge:**

Create a function that takes a string as input and returns the reverse of that string.

**Example:**

Input: `"hello"`

Output: `"olleh"`

#### Solution 1:

```JS
function reverseString(str) {
  let reversed = '';
  for (let i = str.length - 1; i >= 0; i--) {
    reversed += str[i];
  }
  return reversed;
}
```

#### Solution 2:

```JS
function reverseString(str) {
  return str.split('').reverse().join('');
}
```

In Solution 1, we initialize an empty string reversed and then loop through each character in the input string in reverse order, appending each character to reversed.

In Solution 2, we first convert the input string to an array of characters using the split() method. We then use the reverse() method to reverse the order of the array, and finally, we join the elements of the array back into a string using the join() method.


### lower-intermediate 1

**Coding Challenge:**

Create a function that takes an array of numbers as input and returns the largest sum of any two adjacent numbers in the array.

**Example:**

Input: `[1, 2, 3, 4, 5]`

Output: `9 (largest sum is 4 + 5)`

#### Solution 1:

```JS
function largestAdjacentSum(arr) {
  let largestSum = arr[0] + arr[1];
  for (let i = 1; i < arr.length - 1; i++) {
    const sum = arr[i] + arr[i+1];
    if (sum > largestSum) {
      largestSum = sum;
    }
  }
  return largestSum;
}
```

#### Solution 2:

```JS
function largestAdjacentSum(arr) {
  const sums = arr.slice(0, -1).map((num, i) => num + arr[i+1]);
  return Math.max(...sums);
}
```

In Solution 1, we initialize the largestSum variable to the sum of the first two elements in the array. We then loop through the array, computing the sum of each pair of adjacent elements, and updating largestSum if we find a larger sum.

In Solution 2, we first create an array of sums by mapping over the original array with a callback function that adds each number to its adjacent number. We then return the largest element in the sums array using the Math.max() function with the spread syntax.


### lower-intermediate 2

**Coding Challenge:**

Create a function that takes an array of integers as input and returns the index of the first duplicate element in the array. If there are no duplicates, return -1.

**Example:**

Input: `[1, 2, 3, 4, 3, 5]`

Output: `4 (index of first duplicate element is 3)`

#### Solution 1:

```JS
function findFirstDuplicate(arr) {
  const seen = new Set();
  for (let i = 0; i < arr.length; i++) {
    if (seen.has(arr[i])) {
      return i;
    } else {
      seen.add(arr[i]);
    }
  }
  return -1;
}
```

#### Solution 2:

```JS
function findFirstDuplicate(arr) {
  for (let i = 0; i < arr.length; i++) {
    const num = Math.abs(arr[i]);
    if (arr[num - 1] < 0) {
      return num - 1;
    } else {
      arr[num - 1] = -arr[num - 1];
    }
  }
  return -1;
}
```

In Solution 1, we use a Set to keep track of the integers we've seen so far. We loop through the array and check if the current element is in the seen set. If it is, we return the index of the current element. If not, we add the current element to the seen set.

In Solution 2, we utilize the fact that all the integers in the array are positive. We loop through the array and mark each element we encounter as negative by setting arr[num - 1] = -arr[num - 1], where num is the absolute value of the current element. If we encounter a negative element while looping through the array, it means that we've already seen that integer before, so we return its index. If we reach the end of the array without finding a duplicate, we return -1.

### intermediate 1

**Coding Challenge:**

Create a function that takes two arrays of integers as input and returns a new array containing the union of the two arrays (i.e. all the unique integers in both arrays, in any order).

**Example:**

Input: `[1, 2, 3, 4], [3, 4, 5, 6]`

Output: `[1, 2, 3, 4, 5, 6]`

#### Solution 1:

```JS
function unionArrays(arr1, arr2) {
  const set = new Set([...arr1, ...arr2]);
  return Array.from(set);
}
```

#### Solution 2:

```JS
function unionArrays(arr1, arr2) {
  const map = new Map();
  for (let i = 0; i < arr1.length; i++) {
    map.set(arr1[i], true);
  }
  for (let i = 0; i < arr2.length; i++) {
    map.set(arr2[i], true);
  }
  return Array.from(map.keys());
}
```

In Solution 1, we use the Set constructor to create a new set with all the integers from both input arrays. Then we convert the set back into an array using Array.from().

In Solution 2, we use a Map to keep track of the integers we've seen so far. We loop through both input arrays and set each element as a key in the map with a value of true. Then we return an array of the map's keys using Array.from().


### intermediate 2

**Coding Challenge:**

Given an array of integers, write a function that returns the maximum sum of any contiguous subarray within the array. A contiguous subarray is a subset of the original array where the elements are consecutive.

**Example:**

Input: `[1, -2, 3, 4, -5, 8]`

Output: `11`

#### Solution 1:

```JS
function maxSubarraySum(arr) {
  let maxSum = -Infinity;
  let currentSum = 0;
  for (let i = 0; i < arr.length; i++) {
    currentSum = Math.max(arr[i], currentSum + arr[i]);
    maxSum = Math.max(maxSum, currentSum);
  }
  return maxSum;
}
```

#### Solution 2:

```JS
function maxSubarraySum(arr) {
  let maxSum = -Infinity;
  for (let i = 0; i < arr.length; i++) {
    let currentSum = 0;
    for (let j = i; j < arr.length; j++) {
      currentSum += arr[j];
      maxSum = Math.max(maxSum, currentSum);
    }
  }
  return maxSum;
}
```

In Solution 1, we use Kadane's algorithm to find the maximum subarray sum. We loop through the input array and keep track of the maximum sum we've seen so far (maxSum) and the maximum sum of any subarray ending at the current index (currentSum). At each index, we update currentSum to be either the current element or the sum of the current element and the previous subarray sum, whichever is greater. We also update maxSum to be the maximum of maxSum and currentSum at each index.

In Solution 2, we use a nested loop to find the maximum subarray sum. We loop through the input array and for each element, we loop through the remaining elements to find the sum of all contiguous subarrays ending at that element. We update maxSum to be the maximum of maxSum and the sum of all contiguous subarrays we find. This solution has a time complexity of O(n^2), which is less efficient than Solution 1.


### upper-intermediate 1

**Coding Challenge**

You are given a list of objects representing books. Each book has a title, an author, and a price. Write a function that takes the list of books as input and returns a new list of objects containing only the books that have unique titles. If there are multiple books with the same title, none of them should be included in the output list.

**Example:**

Input:

```yaml
[
  {title: 'Harry Potter', author: 'J.K. Rowling', price: 20},
  {title: 'The Hunger Games', author: 'Suzanne Collins', price: 15},
  {title: 'Harry Potter', author: 'J.K. Rowling', price: 25},
  {title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 10},
  {title: 'The Catcher in the Rye', author: 'J.D. Salinger', price: 12}
]
```

Output:

```yaml
[
  {title: 'The Hunger Games', author: 'Suzanne Collins', price: 15},
  {title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 10},
  {title: 'The Catcher in the Rye', author: 'J.D. Salinger', price: 12}
]
```

#### Solution 1:

```JS
function getUniqueBooks(books) {
  let titleCounts = {};
  for (let i = 0; i < books.length; i++) {
    let title = books[i].title;
    if (!titleCounts.hasOwnProperty(title)) {
      titleCounts[title] = 1;
    } else {
      titleCounts[title]++;
    }
  }
  let uniqueBooks = [];
  for (let i = 0; i < books.length; i++) {
    if (titleCounts[books[i].title] === 1) {
      uniqueBooks.push(books[i]);
    }
  }
  return uniqueBooks;
}
```

#### Solution 2:

```JS
function getUniqueBooks(books) {
  let uniqueTitles = [];
  let duplicateTitles = [];
  for (let i = 0; i < books.length; i++) {
    let title = books[i].title;
    if (uniqueTitles.includes(title)) {
      duplicateTitles.push(title);
    } else {
      uniqueTitles.push(title);
    }
  }
  let uniqueBooks = [];
  for (let i = 0; i < books.length; i++) {
    if (!duplicateTitles.includes(books[i].title)) {
      uniqueBooks.push(books[i]);
    }
  }
  return uniqueBooks;
}
```

In Solution 1, we loop through the input list of books twice. In the first loop, we create an object titleCounts that counts the number of occurrences of each title in the input list. In the second loop, we check if the count of the current book's title is 1 in titleCounts. If it is, we add the book to a new list uniqueBooks that contains only books with unique titles.

In Solution 2, we loop through the input list of books once. We maintain two lists uniqueTitles and duplicateTitles. If we encounter a title that is already in uniqueTitles, we add it to duplicateTitles. Otherwise, we add it to uniqueTitles. After we've looped through all the books, we create a new list uniqueBooks that contains only books whose titles are not in duplicateTitles.


### upper-intermediate 2

**Coding Challenge:**

Given an array of numbers, write a function that returns the two numbers that sum up to a specific target value. The function should return an array containing the indices of the two numbers in the original array. Assume that there is exactly one solution and you may not use the same element twice.

**Example:**

Input: `[2, 7, 11, 15], target = 9`

Output: `[0, 1] (indices of numbers 2 and 7 that sum up to 9)`

#### Solution 1

```JS
function twoSum(arr, target) {
  const numMap = new Map();
  for (let i = 0; i < arr.length; i++) {
    const complement = target - arr[i];
    if (numMap.has(complement)) {
      return [numMap.get(complement), i];
    }
    numMap.set(arr[i], i);
  }
  return [];
}
```

#### Solution 2

```JS
function twoSum(arr, target) {
  const numSet = new Set();
  for (let i = 0; i < arr.length; i++) {
    const complement = target - arr[i];
    if (numSet.has(complement)) {
      const j = arr.findIndex(num => num === complement);
      return [j, i];
    }
    numSet.add(arr[i]);
  }
  return [];
}
```

In Solution 1, we use a Map data structure to store the numbers in the input array as keys and their corresponding indices as values. We loop through the array and for each element, we calculate its complement (target minus the element value). If the complement is found in the map, we retrieve its index and the current index and return them as the solution.

In Solution 2, we use a Set data structure to store the numbers in the input array. We loop through the array and for each element, we calculate its complement. If the complement is found in the set, we use Array.findIndex() to find its index in the original array and return the complement's index and the current index as the solution.

Both solutions have a time complexity of O(n), where n is the size of the input array, as we iterate through the array only once.

### advanced 1

**Coding Challenge:**

Given an array of integers, write a function to find the longest subarray where the absolute difference between any two adjacent elements is at most 1. For example, if the input array is [0, 1, 1, 2, 2, 2, 1, 1], the output should be [1, 1, 2, 2, 2], as this is the longest subarray that satisfies the given condition.

#### Solution 1:

We can solve this problem using dynamic programming. Let dp[i] be the length of the longest subarray ending at index i that satisfies the given condition. Then we can calculate dp[i] as follows:


dp[i] = 1 + max(dp[j]), where 0 <= j < i and abs(arr[i] - arr[j]) <= 1
In other words, we look at all the previous indices j such that the absolute difference between arr[i] and arr[j] is at most 1, and take the maximum dp[j]. We add 1 to this value to include the current element arr[i] in the subarray.

To find the actual subarray, we can keep track of the index k that gives the maximum dp[k] and use it to backtrack the subarray.

The time complexity of this solution is O(n^2), where n is the length of the input array, as we loop through the array twice.

#### Solution 2:

We can optimize the above solution using two pointers. We maintain two pointers left and right that point to the start and end indices of the current subarray that satisfies the condition. We initialize both pointers to 0, and then increment right until the absolute difference between arr[right] and arr[right-1] is greater than 1. At this point, we update the subarray to be the longest subarray so far, and increment left until the absolute difference between arr[left] and arr[left-1] is greater than 1. We repeat this process until right reaches the end of the array.

The time complexity of this solution is O(n), where n is the length of the input array, as we loop through the array only once.

Note that this solution only works if the array contains integers. If the array can contain floating-point numbers, we would need to use a tolerance value instead of a fixed difference of 1.

### advanced 2

**Coding Challenge:**

You are given an array of strings representing a list of courses. Each string in the array is formatted as <course_name>:<prerequisite_course1>,<prerequisite_course2>,.... Write a function that takes the array of courses as input and returns a valid ordering of the courses such that all prerequisites are fulfilled. If there are multiple valid orderings, you can return any one of them. If it is not possible to find a valid ordering due to cyclic dependencies, return an empty array.

**Example:**

Input: `['Math:Algebra,Calculus', 'Calculus:Geometry', 'Geometry:', 'History:', 'Physics:Math', 'Chemistry:Math', 'English:History']`

Output: `['Geometry', 'History', 'Algebra', 'Calculus', 'Math', 'Physics', 'Chemistry', 'English']`

#### Solution:

We can solve this problem using a depth-first search (DFS) algorithm. First, we need to parse the input array to create a graph representation of the courses and their prerequisites. Then, we can perform a DFS traversal starting from each course to build the valid ordering. We maintain three sets: visited to keep track of visited courses, inProgress to detect cyclic dependencies, and order to store the valid ordering.

**Here is an outline of the algorithm:**

- Parse the input array to create a graph representation (e.g., using a hashmap or an adjacency list).
- Initialize the visited, inProgress, and order sets.
- Iterate over each course in the input array.
- For each course, if it has not been visited, call the DFS function.
- In the DFS function:
- If the course is in progress, there is a cyclic dependency, so return false.
- If the course has already been visited, return true.
- Add the course to the in-progress set.
- Recursively call the DFS function for each prerequisite course.
- Remove the course from the in-progress set and add it to the visited set.
- Add the course to the order set.
- Return true.
- If the DFS function returns false for any course, there is a cyclic dependency, so return an empty array.
- If the DFS function returns true for all courses, return the order set as the valid ordering.

The time complexity of this solution is O(V + E), where V is the number of courses and E is the number of prerequisites, as we need to traverse all the vertices and edges in the graph representation of the courses.


### mastery 1

**Coding Challenge**

You are given an array of objects representing people. Each object has the following properties:

```JS
{
  name: string,    // name of the person
  age: number,     // age of the person
  city: string,    // city where the person lives
  country: string  // country where the person lives
}
```

Write a function that takes in this array and returns an object with the following properties:

```JS
{
  averageAge: number,          // average age of all the people in the array
  mostCommonCity: string,      // name of the city that most people live in
  mostCommonCountry: string,   // name of the country that most people live in
  uniqueCountries: string[]    // list of unique country names in alphabetical order
}
```

#### Solution 1

```JS
function analyzePeople(people) {
  const totalAge = people.reduce((acc, person) => acc + person.age, 0);
  const averageAge = totalAge / people.length;

  const cities = {};
  const countries = {};
  let mostCommonCity = '';
  let mostCommonCountry = '';
  let maxCityCount = 0;
  let maxCountryCount = 0;

  people.forEach(person => {
    cities[person.city] = cities[person.city] ? cities[person.city] + 1 : 1;
    countries[person.country] = countries[person.country] ? countries[person.country] + 1 : 1;

    if (cities[person.city] > maxCityCount) {
      maxCityCount = cities[person.city];
      mostCommonCity = person.city;
    }

    if (countries[person.country] > maxCountryCount) {
      maxCountryCount = countries[person.country];
      mostCommonCountry = person.country;
    }
  });

  const uniqueCountries = Object.keys(countries).sort();

  return {
    averageAge,
    mostCommonCity,
    mostCommonCountry,
    uniqueCountries,
  };
}
```

#### Solution 2

```JS
function analyzePeople(people) {
  const ageSum = people.reduce((acc, { age }) => acc + age, 0);
  const averageAge = ageSum / people.length;

  const cities = {};
  const countries = {};
  let maxCityCount = 0;
  let maxCountryCount = 0;

  people.forEach(({ city, country }) => {
    cities[city] = cities[city] + 1 || 1;
    countries[country] = countries[country] + 1 || 1;

    if (cities[city] > cities[maxCityCount]) {
      maxCityCount = city;
    }

    if (countries[country] > countries[maxCountryCount]) {
      maxCountryCount = country;
    }
  });

  const uniqueCountries = [...new Set(people.map(({ country }) => country))].sort();

  return {
    averageAge,
    mostCommonCity: maxCityCount,
    mostCommonCountry: maxCountryCount,
    uniqueCountries,
  };
}
```

Note that the two solutions achieve the same result, but use slightly different approaches. The first solution uses a forEach loop to iterate over the people array and populate the cities and countries objects with counts for each city and country. It then finds the most common city and country using another forEach loop.

The second solution uses the reduce method to calculate the total age and a forEach loop to populate the cities and countries objects with counts for each city and country.


### mastery 2

Write a function that takes an array of integers as input and returns the length of the longest increasing subsequence in the array. A subsequence is a sequence that can be derived from the input array by deleting some or no elements without changing the order of the remaining elements. An increasing subsequence is a subsequence in which the elements are in increasing order.

For example, given the input array [10, 9, 2, 5, 3, 7, 101, 18], the longest increasing subsequence is [2, 5, 7, 101], and its length is 4.

Note that the subsequence does not have to be contiguous, and there may be multiple increasing subsequences with the same maximum length.


#### Solution 1: Dynamic Programming

```JS
function longestIncreasingSubsequenceLength(nums) {
  const n = nums.length;
  const dp = new Array(n).fill(1);
  
  for (let i = 1; i < n; i++) {
    for (let j = 0; j < i; j++) {
      if (nums[j] < nums[i]) {
        dp[i] = Math.max(dp[i], dp[j] + 1);
      }
    }
  }
  
  return Math.max(...dp);
}
```

In this solution, we use dynamic programming to solve the problem. We create an array dp where dp[i] represents the length of the longest increasing subsequence ending at index i of the input array. We initialize dp with all 1's because each element of the input array is an increasing subsequence of length 1. Then we iterate through the input array from left to right, and for each element at index i, we iterate through all elements to its left at indices j from 0 to i-1. If the element at index j is less than the element at index i, it can be included in the increasing subsequence ending at index i, so we update dp[i] to be the maximum between its current value and dp[j] + 1. Finally, we return the maximum value in the dp array.

### Solution 2: Binary Search

```JS
function longestIncreasingSubsequenceLength(nums) {
  const tails = new Array(nums.length);
  let size = 0;
  
  for (let x of nums) {
    let i = 0, j = size;
    while (i < j) {
      let m = Math.floor((i + j) / 2);
      if (tails[m] < x) {
        i = m + 1;
      } else {
        j = m;
      }
    }
    tails[i] = x;
    if (i === size) size++;
  }
  
  return size;
}
```

In this solution, we use a technique called binary search to solve the problem more efficiently. We create an array tails where tails[i] represents the smallest tail element of all increasing subsequences of length i+1 that we have found so far. We initialize tails with all 0's because we haven't found any increasing subsequences yet. Then we iterate through the input array from left to right, and for each element x, we use binary search to find the smallest index i such that tails[i] is greater than or equal to x. If such an index exists, we update tails[i] to be x, because we have found a longer increasing subsequence that ends with x. If not, we set tails[size] to be x, where size is the current length of the longest increasing subsequence we have found so far. Finally, we return size, which is the length of the longest increasing subsequence.

---


## Debugging Challenge

### Beginner 1

**Challenge:**

The following code is supposed to print out the numbers from 1 to 5 in the console. However, there is a bug in the code that prevents it from doing so. Find and fix the bug so that the code outputs the correct numbers.

```JS
for (var i = 1; i < 5; i++) {
  console.log(i);
}
```

#### Solution 1

The issue with the code is that the loop condition is incorrect. The loop condition should be i <= 5 instead of i < 5. Here's the fixed code:

```JS
for (var i = 1; i <= 5; i++) {
  console.log(i);
}
```

#### Solution 2

Alternatively, the code can also be fixed by changing the initial value of i to 0 instead of 1. Here's the fixed code:

```JS
for (var i = 0; i < 5; i++) {
  console.log(i + 1);
}
```

In this solution, we added 1 to the value of i in the console.log() statement to print out the correct numbers from 1 to 5.

### Beginner 1

**Challenge:**

The following code is supposed to print out the names of the fruits in the fruits array in the console. However, there is a bug in the code that prevents it from doing so. Find and fix the bug so that the code outputs the correct names of the fruits.

```JS
var fruits = ["Apple", "Banana", "Orange"];

for (i = 0; i < fruits.length; i++) {
  console.log(fruit);
}
```

#### Solution 1

The issue with the code is that the loop variable is not defined. In the for loop, we need to define the loop variable using the var keyword. Here's the fixed code:

```JS
var fruits = ["Apple", "Banana", "Orange"];

for (var i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
}
```

In this solution, we used fruits[i] to access each element of the fruits array using the loop variable i.

#### Solution 2

Alternatively, we can also use a for...of loop to iterate through the elements of the fruits array. Here's the fixed code:

```JS
var fruits = ["Apple", "Banana", "Orange"];

for (var fruit of fruits) {
  console.log(fruit);
}
```

In this solution, we used the for...of loop to directly iterate through each element of the fruits array and print it in the console.

### Lower-intermediate 1

**Problem Description**

The following JavaScript function is supposed to take an array of numbers as input and return the sum of all the even numbers in the array. However, it is not working as expected. Your task is to debug the function and fix the issue.

```JS
function sumOfEvenNumbers(arr) {
  let sum = 0;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
      sum += arr[i];
    }
  }
  return sum;
}
```

**Example Input/Output:**

```c
Input: [1, 2, 3, 4, 5, 6]
Output: 12
Input: [10, 15, 20, 25]
Output: 30
Input: [-2, 5, 7, 8, 10]
Output: 16
```

**Your Task:**

Your task is to find and fix the bug in the given function. You need to provide the corrected version of the function.

#### Solution 1

```JS
function sumOfEvenNumbers(arr) {
  let sum = 0;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
      sum += arr[i];
    }
  }
  return sum;
}
```

#### Solution 2

```JS
function sumOfEvenNumbers(arr) {
  let sum = 0;
  arr.forEach((num) => {
    if (num % 2 === 0) {
      sum += num;
    }
  });
  return sum;
}
```

### Lower-intermediate 2

**Challenge:**

The following code is supposed to create a simple calculator that takes two numbers and an operator (+, -, *, /) and returns the result. However, it seems to be producing incorrect results for some inputs. Find and fix the bug(s) in the code.

```JS
function calculate(num1, num2, operator) {
  switch(operator) {
    case '+':
      return num1 - num2;
    case '-':
      return num1 + num2;
    case '*':
      return num1 / num2;
    case '/':
      return num1 * num2;
    default:
      return 'Invalid operator';
  }
}

console.log(calculate(10, 5, '+')); // should output 15
console.log(calculate(10, 5, '-')); // should output 5
console.log(calculate(10, 5, '*')); // should output 50
console.log(calculate(10, 5, '/')); // should output 2
console.log(calculate(10, 5, '%')); // should output 'Invalid operator'
```

**Expected output:**

```c
15
5
50
2
'Invalid operator'
```

#### Solution 1

```JS
function calculate(num1, num2, operator) {
  switch(operator) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case '*':
      return num1 * num2;
    case '/':
      return num1 / num2;
    default:
      return 'Invalid operator';
  }
}
```

#### Solution 2

```JS
function calculate(num1, num2, operator) {
  if (typeof num1 !== 'number' || typeof num2 !== 'number') {
    return 'Invalid input';
  }
  
  switch(operator) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case '*':
      return num1 * num2;
    case '/':
      return num1 / num2;
    default:
      return 'Invalid operator';
  }
}
```

### Intermediate 1

**Problem:**

The goal of this coding challenge is to fix a buggy JavaScript function. The function is supposed to return the sum of all numbers in an array, but it is currently returning an incorrect value.

```JS
function sumArray(arr) {
  let sum = 0;
  for (let i = 1; i < arr.length; i++) {
    sum += arr[i];
  }
  return sum;
}
Instructions:
```

Debug the function to make it return the correct sum of all numbers in the array.
The function should work for arrays of any length.

**Examples:**

```JS
sumArray([1, 2, 3, 4, 5]); // Should return 15
sumArray([-10, 5, 20, 30]); // Should return 45
sumArray([100, -50, 25, 10]); // Should return 85
```

Note:

The bug is not very obvious, but it is related to the loop condition.

#### Solution 1

```JS
function sumArray(arr) {
  let sum = 0;
  for (let i = 0; i < arr.length; i++) { //fixed loop condition from i = 1 to i = 0
    sum += arr[i];
  }
  return sum;
}
```

#### Solution 2

```JS
function sumArray(arr) {
  let sum = 0;
  arr.forEach(num => sum += num); // using forEach method to avoid using loop
  return sum;
}
```

The first solution fixed the loop condition from let i = 1 to let i = 0. The second solution used the forEach method to avoid using a loop entirely. Both solutions will return the correct sum of all numbers in the array.

### Intermediate 2

**Problem:**

The following function is supposed to remove all duplicates from an array and return a new array with unique elements only, but it is not working properly. Can you debug and fix the code?

```JS
function removeDuplicates(arr) {
  let uniqueArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (!uniqueArr.includes(arr[i])) {
      uniqueArr.push(arr[i]);
    }
  }
  return uniqueArr;
}

console.log(removeDuplicates([1, 2, 3, 3, 4, 4, 5])); // expected output: [1, 2, 3, 4, 5]
```

#### Solution 1

```JS
function removeDuplicates(arr) {
  let uniqueArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (!uniqueArr.includes(arr[i])) {
      uniqueArr.push(arr[i]);
    } else {
      continue;
    }
  }
  return uniqueArr;
}
console.log(removeDuplicates([1, 2, 3, 3, 4, 4, 5])); // expected output: [1, 2, 3, 4, 5]
```

#### Solution 2

```JS
function removeDuplicates(arr) {
  let uniqueArr = [];
  let tempObj = {};
  for (let i = 0; i < arr.length; i++) {
    if (!tempObj[arr[i]]) {
      tempObj[arr[i]] = true;
      uniqueArr.push(arr[i]);
    }
  }
  return uniqueArr;
}
console.log(removeDuplicates([1, 2, 3, 3, 4, 4, 5])); // expected output: [1, 2, 3, 4, 5]
```

### Upper-intermediate 1

**Problem Statement**

The following JavaScript code is supposed to print out the sum of all odd numbers from 1 to 10:

```JS
let sum = 0;
for (let i = 0; i <= 10; i++) {
  if (i % 2 != 0) {
    sum += i;
  }
}
console.log(`Sum of odd numbers from 1 to 10 is: ${sum}`);
```

However, when the code is executed, it does not print the expected output. Your task is to debug the code and fix the issue.

**Expected Output**

`Sum of odd numbers from 1 to 10 is: 25`

#### Solution 1

The issue in the code is that the loop is running one extra iteration, which is causing the sum to include the number 10 (which is even). To fix the issue, we can simply change the loop condition to i < 10 instead of i <= 10. Here's the corrected code:

```JS
let sum = 0;
for (let i = 1; i < 10; i++) {
  if (i % 2 !== 0) {
    sum += i;
  }
}
console.log(`Sum of odd numbers from 1 to 10 is: ${sum}`);
```

#### Solution 2

Another way to fix the issue is to remove the if statement inside the loop, and instead only add odd numbers to the sum. Here's the corrected code:

```JS
let sum = 0;
for (let i = 1; i <= 10; i += 2) {
  sum += i;
}
console.log(`Sum of odd numbers from 1 to 10 is: ${sum}`);
```

Both solutions should produce the expected output of Sum of odd numbers from 1 to 10 is: 25.


### Upper-intermediate 2

**Challenge: Word Frequency**

Write a function countWords(str) that takes a string as input and returns an object containing the frequency of each word in the string. For example, countWords('the quick brown fox jumped over the lazy dog') should return {the: 2, quick: 1, brown: 1, fox: 1, jumped: 1, over: 1, lazy: 1, dog: 1}.

However, the function currently has a bug that causes it to return an incorrect frequency count for some words. Your task is to identify and fix the bug.

```JS
function countWords(str) {
  let words = str.split(" ");
  let freq = {};
  for (let i = 0; i < words.length; i++) {
    if (freq[words[i]] == undefined) {
      freq[words[i]] = 1;
    } else {
      freq[words[i]]++;
    }
  }
  return freq;
}

console.log(countWords("the quick brown fox jumped over the lazy dog")); // expected output: {the: 2, quick: 1, brown: 1, fox: 1, jumped: 1, over: 1, lazy: 1, dog: 1}
```


#### Solution 1

```JS
function findDuplicate(arr) {
  const seen = {};
  for (let i = 0; i < arr.length; i++) {
    if (seen[arr[i]]) {
      return arr[i];
    } else {
      seen[arr[i]] = true;
    }
  }
  return null;
}
```

#### Solution 2

```JS
function findDuplicate(arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[Math.abs(arr[i])] >= 0) {
      arr[Math.abs(arr[i])] = -arr[Math.abs(arr[i])];
    } else {
      return Math.abs(arr[i]);
    }
  }
  return null;
}
```

In solution 1, we use an object to keep track of the numbers we've already seen in the array. We loop through each element of the array, and if we see an element that we've already seen before, we return it as the duplicate.

In solution 2, we modify the input array itself to keep track of the numbers we've already seen. We loop through each element of the array, and for each element arr[i], we check whether the value at index arr[Math.abs(arr[i])] is positive or negative. If it's positive, we flip its sign to indicate that we've seen that number before. If it's negative, we know that we've seen that number before and we return it as the duplicate.



### Advanced 1

**Coding Challenge: Debugging a Recursive Function**

You need to write a function recursiveSum(n) that takes a positive integer n and returns the sum of all the numbers from 1 to n. However, the implementation of the function has some bugs that need to be fixed. Your task is to debug the function and make sure that it returns the correct output for any valid input.

Here's the initial implementation of the function:

```JS
function recursiveSum(n) {
  if (n === 0) {
    return 0;
  } else {
    recursiveSum(n - 1);
    return n + recursiveSum(n - 1);
  }
}
```

**Requirements**

- The function should take a positive integer as an argument and return the sum of all the numbers from 1 to that integer, inclusive.
- You are not allowed to use any loops (e.g. for, while) or built-in functions like Array.reduce().
- Your implementation should be recursive and use the provided recursiveSum function.

**Examples**

```JS
recursiveSum(5); // should return 15 (1 + 2 + 3 + 4 + 5)
recursiveSum(10); // should return 55 (1 + 2 + ... + 9 + 10)
```

**Bugs to Fix**

The current implementation of recursiveSum has a few bugs that need to be fixed. Here are some hints to help you find them:

- The function doesn't return the correct output for n > 1.
- The function doesn't use recursion correctly.
- The function doesn't handle the base case (n === 0) correctly.


#### Solution 1

```JS
function recursiveSum(n) {
  if (n === 0) {
    return 0;
  } else {
    return n + recursiveSum(n - 1);
  }
}
```

#### Solution 2

```JS
function recursiveSum(n) {
  if (n === 1) {
    return 1;
  } else {
    return n + recursiveSum(n - 1);
  }
}
```

Both of these solutions work correctly and satisfy the requirements of the challenge. The key is to make sure that the base case (n === 0 or n === 1) is handled correctly, and that the function uses recursion correctly to compute the sum.



### Advanced 2

**Challenge**

You are given an array of objects, each representing a person and their age. Your task is to write a function getAgeStats that takes the array as an argument and returns an object with the following 

**statistics:**

- `minAge` : the minimum age in the array
- `maxAge` : the maximum age in the array
- `avgAge` : the average age of all the people in the array

However, there is a bug in the code that needs to be fixed before it can produce correct results.

```JS
function getAgeStats(people) {
  let minAge = people[0].age;
  let maxAge = people[0].age;
  let totalAge = 0;

  for (let i = 1; i < people.length; i++) {
    if (people[i].age < minAge) {
      minAge = people[i].minAge;
    }
    if (people[i].age > maxAge) {
      maxAge = people[i].maxAge;
    }
    totalAge += people[i].age;
  }

  const avgAge = totalAge / people.length;

  return { minAge, maxAge, avgAge };
}

const people = [
  { name: "Alice", age: 30 },
  { name: "Bob", age: 25 },
  { name: "Charlie", age: 35 },
  { name: "David", age: 40 },
];

console.log(getAgeStats(people)); // should output { minAge: 25, maxAge: 40, avgAge: 32.5 }
```

Your task is to fix the bug in the getAgeStats function so that it correctly computes the statistics for the array of people.

Note:
- The bug is related to the variables used for computing the minimum and maximum age.
- The getAgeStats function should work correctly for any array of objects with a name and age property.
- You can assume that the input array will always have at least one element.


#### Solution 1

```JS
function reverseString(str) {
  let reversed = '';
  for (let i = str.length - 1; i >= 0; i--) {
    reversed += str[i];
  }
  return reversed;
}

function reverseWords(sentence) {
  const words = sentence.split(' ');
  for (let i = 0; i < words.length; i++) {
    words[i] = reverseString(words[i]);
  }
  return words.join(' ');
}

console.log(reverseWords('The quick brown fox')); // ehT kciuq nworb xof
```

#### Solution 2

```JS
function reverseWords(sentence) {
  const words = sentence.split(' ');
  const reversed = words.map(word => word.split('').reverse().join(''));
  return reversed.join(' ');
}

console.log(reverseWords('The quick brown fox')); // ehT kciuq nworb xof
```

Both solutions use the split() method to split the input string into an array of words, and then loop through each word to reverse its characters. The first solution uses a for loop to reverse the characters of each word, while the second solution uses the map() method to create a new array of reversed words by mapping each word to a new string that is the reverse of the original. Finally, both solutions join the reversed words back into a string using the join() method.


### Mastery 1

**Challenge:**

The following code is supposed to count the number of occurrences of each letter in a given string and return an object containing the results. However, there seems to be a bug in the code that is causing it to produce incorrect output. Your task is to find and fix the bug.

```JS
function countLetters(str) {
  const count = {};
  for (let i = 0; i < str.length; i++) {
    if (count[str[i]]) {
      count[str[i]]++;
    } else {
      count[str[i]] = 1;
    }
  }
  return count;
}

console.log(countLetters('hello world'));
// Expected output: { h: 1, e: 1, l: 3, o: 2, ' ': 1, w: 1, r: 1, d: 1 }
```

#### Solution 1

```JS
function countLetters(str) {
  const count = {};
  for (let i = 0; i < str.length; i++) {
    if (count[str[i]]) {
      count[str[i]]++;
    } else {
      count[str[i]] = 1;
    }
  }
  return count;
}

console.log(countLetters('hello world'));
// { h: 1, e: 1, l: 3, o: 2, ' ': 1, w: 1, r: 1, d: 1 }
```

#### Solution 2

```JS
function countLetters(str) {
  const count = {};
  for (let i = 0; i < str.length; i++) {
    if (count[str[i]]) {
      count[str[i]]++;
    } else {
      count[str[i]] = 1;
    }
  }
  return count;
}

console.log(countLetters('aabbcdeeffgg'));
// { a: 2, b: 2, c: 1, d: 1, e: 2, f: 2, g: 2 }
```


### Mastery 2

**Problem:**

You are given a function that is intended to return the average of an array of integers. However, there seems to be a bug in the function that is causing it to return the wrong result. Your task is to find the bug and fix it.


```JS
function findAverage(arr) {
  let sum = 0;
  let len = arr.length;
  
  for(let i = 0; i <= len; i++) {
    sum += arr[i];
  }

  let average = sum / len;
  
  return average;
}
```

**Expected Output:**

`findAverage([1, 2, 3, 4, 5]) // should return 3`

**Constraints:**

- You must fix the existing code, you cannot rewrite it.
- The length of the array will always be greater than 0.
- The array will only contain integers.



### Solution

To fix the issue, we need to change the loop condition from i <= nums.length to i < nums.length, because arrays in JavaScript are 0-indexed, meaning that the first element is at index 0, and the last element is at index nums.length - 1. So, if we start the loop at index 1 and go up to nums.length, we're actually skipping the first element and including an undefined element at the end.

Here is the corrected code:

```JS
function findAverage(nums) {
  var sum = 0;
  for (var i = 0; i < nums.length; i++) {
    sum += nums[i];
  }
  var avg = sum / nums.length;
  return avg;
}
```
